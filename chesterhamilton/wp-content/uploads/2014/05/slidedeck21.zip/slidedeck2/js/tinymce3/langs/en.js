tinyMCE.addI18n("en.slidedeck2",{
	title : "Embed a SlideDeck"
});