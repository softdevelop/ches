<div id="slidedeck-social-buttons" class="right-column-module"<?php echo( !SlideDeckLitePlugin::get_partner_data() )? '':' style="border-top:0;"' ?>>
    <strong>Share with friends</strong>
    <div class="tweeet-button social-button">
        <a href="https://twitter.com/share" class="twitter-share-button" data-url="http://demo.slidedeck.com/wp-login.php" data-text="I just made a WordPress content slider in minutes! Try the free @SlideDeck 2 demo. Please RT">Tweet</a>
        <script>!function(d,s,id){var js,fjs=d.getElementsByTagName(s)[0];if(!d.getElementById(id)){js=d.createElement(s);js.id=id;js.src="//platform.twitter.com/widgets.js";fjs.parentNode.insertBefore(js,fjs);}}(document,"script","twitter-wjs");</script>
    </div>                
    <div class="like-button social-button">
        <iframe src="//www.facebook.com/plugins/like.php?href=http%3A%2F%2Fdemo.slidedeck.com%2Fwp-login.php&amp;send=false&amp;layout=button_count&amp;width=450&amp;show_faces=false&amp;action=like&amp;colorscheme=light&amp;font&amp;height=35" scrolling="no" frameborder="0" style="border:none; overflow:hidden; width:450px; height:35px;" allowTransparency="true"></iframe>
    </div>
    <div class="plusone-button social-button">
        <!-- Place this tag where you want the +1 button to render. -->
		<div class="g-plusone" data-size="medium" data-href="http://demo.slidedeck.com/wp-login.php"></div>
		
		<!-- Place this tag after the last +1 button tag. -->
		<script type="text/javascript">
		  (function() {
		    var po = document.createElement('script'); po.type = 'text/javascript'; po.async = true;
		    po.src = 'https://apis.google.com/js/plusone.js';
		    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(po, s);
		  })();
		</script>
    </div>
</div>