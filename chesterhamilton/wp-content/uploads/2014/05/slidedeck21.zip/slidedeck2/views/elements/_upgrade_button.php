<div class="upgrade-button-cta">
    <span class="message"><?php echo $values['message_text']; ?></span>
    <a href="<?php echo $values['cta_url']; ?>&referrer=<?php echo urlencode( "Upgrade Button ({$values['context']})" ); ?>" class="upgrade-button green"><span class="button-noise"><span><?php echo $values['cta_text']; ?></span></span></a>
</div>