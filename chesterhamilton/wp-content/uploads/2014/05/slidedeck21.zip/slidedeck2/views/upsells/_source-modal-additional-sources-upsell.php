<div id="lite-upsell-additional-sources">
    <div class="header">
        <div class="left">
            <h4>Need more sources?</h4>
            <p>Get more sources, lenses, unlimited slides and more</p>
        </div>
        <div class="right">
            <a href="<?php echo slidedeck2_action( "/upgrades&referrer=More+Sources+Handslap" ); ?>" class="button slidedeck-noisy-button">Upgrade to Personal</a>
        </div>
    </div>
    <img height="228" src="<?php echo SLIDEDECK2_URLPATH; ?>/images/sources-modal-upsell-source-list.png" alt="Available Sources">
</div>